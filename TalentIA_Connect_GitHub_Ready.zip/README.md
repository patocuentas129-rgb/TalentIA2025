# TalentIA Connect (Demo)

Una SPA estática en HTML/JS para demostrar un dashboard de aprendizaje con preferencia de tema/idioma, login simulado con *loader* y gráficos en Chart.js.

## Estructura
- `index.html` — aplicación completa en un archivo.

## Cómo publicarlo en GitHub Pages
1. Crea un repositorio nuevo en GitHub (por ejemplo: `talentia-connect`).
2. Sube el archivo `index.html` a la rama `main` (o `master`).
3. En **Settings → Pages**, en *Source* elige `Deploy from a branch` y selecciona la rama (`main`) y la carpeta `/root`.
4. Guarda. La URL estará en el bloque de GitHub Pages, algo como: `https://<tu-usuario>.github.io/talentia-connect/`

> Tip: Si no ves la página, espera unos segundos y refresca (Ctrl+R).

## Licencia
MIT (opcional).
